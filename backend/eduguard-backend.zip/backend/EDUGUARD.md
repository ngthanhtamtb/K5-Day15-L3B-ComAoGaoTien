# EduGuard backend (RAGslides-be + quiz + voice)

Toàn bộ RAGslides-be được giữ nguyên (auth, presentations, templates, sinh outline/slide, media…).
Phần mở rộng nằm ở `app/edu/` và route `/api/v1/edu/*` (file `app/api/v1/endpoints/edu.py`).

## Chạy

```bash
cd backend
cp .env.example .env          # điền GEMINI_API_KEY, FERNET_KEY, DATABASE_URL
python -c "import base64,os;print(base64.b64encode(os.urandom(32)).decode())"   # -> FERNET_KEY
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8077 --reload
# Swagger: http://localhost:8077/api-docs  (nhóm "EduGuard")
```

Postgres vẫn cần cho các route cũ của RAGslides. Các route `/edu/*` lưu file JSON trong
`data/edu/` nên chạy được ngay; ảnh/audio được phục vụ qua `/static/edu/...` (mount sẵn của main.py).

## Cấu trúc `app/edu/`

| Thư mục | Vai trò |
|---|---|
| `docparse/docx_parser.py` | Parser .docx gốc: giữ thứ tự ảnh/bảng, auto-numbering ("Câu %1.", "A."), ô gộp, bảng lồng, text box, OMML→LaTeX, WMF/EMF→PNG, định dạng run (gạch chân/đỏ/highlight) |
| `docparse/other_parsers.py` | PDF/PPTX: Docling local nếu cài, không thì gọi `EXTRACT_DOC_API_URL` cũ; .doc/.ppt qua LibreOffice |
| `docparse/service.py` | Ingest → markdown + chunk theo heading (ảnh/bảng không bị tách khỏi đoạn văn) |
| `retrieval/bm25.py` | BM25 không phụ thuộc thư viện (unigram + bigram tiếng Việt) cho source grounding |
| `quiz/extractor.py` | Trích câu hỏi từ đề: MCQ, Đúng/Sai a)–d), trả lời ngắn; đáp án từ bảng đáp án / "Đáp án: B" / gạch chân / chữ đỏ / highlight / in đậm duy nhất |
| `quiz/engines.py` | `ZentusQuizEngine` (BE_Zentus) và `GeminiQuizEngine` (dùng `app/core/pptagent/llm_client.py` của RAGslides, có gửi ảnh cho model) |
| `quiz/evaluator.py` | Eval → `baseMetrics`, `source`, `fixes` (khớp tên trường của frontend) |
| `tts/` | Provider TTS: `silent` (test), `http` (cấu hình bằng .env) |
| `voice/service.py` | Lời giảng `slide.remark`, TTS có cache, gắn audio element PPTist (autoplay) |

## Nối BE_Zentus

```
QUIZ_ENGINE=zentus
ZENTUS_PATH=E:/Python_Project/VinAI_Lab/BE_Zentus
ZENTUS_GENERATE_FN=<module>:<function>
```
Hàm được gọi với các tham số mà nó khai báo trong số: `text|content|document` (markdown),
`chunks`, `num_questions|n`, `language`, `bloom_mix`, `question_types`, `images`.
Sync/async đều được; trả list dict / {"questions": [...]} / pydantic / chuỗi JSON đều được.
Tên trường thường gặp (`question|stem`, `choices|options`, `answer|correct_answer`, `explanation`…)
được map tự động trong `normalise_question()`. Nếu import lỗi, hệ thống tự dùng Gemini và ghi log.

## Nối API voice

Đổi `TTS_PROVIDER=http` và điền `TTS_API_URL`, `TTS_API_KEY`, `TTS_REQUEST_TEMPLATE`,
`TTS_RESPONSE_TYPE` (`binary` | `json_base64` | `json_url`), `TTS_RESPONSE_FIELD`.
API kiểu submit job rồi poll: kế thừa `HttpTTS` và override `synthesize()`.

## API chính (`/api/v1/edu`)

| Method | Path | Việc |
|---|---|---|
| POST | `/documents` | Upload + parse (docx/pdf/pptx/doc/md) |
| GET | `/documents/{docId}` | Blocks, images, tables, chunks |
| GET | `/documents/{docId}/search?q=` | Tìm đoạn nguồn |
| POST | `/documents/{docId}/quiz/extract` | Trích câu hỏi từ đề có sẵn |
| POST | `/documents/{docId}/quiz/generate` | Sinh câu hỏi (BE_Zentus / Gemini) |
| GET | `/quizzes/{quizId}` | Lấy bộ quiz |
| POST | `/quizzes/{quizId}/evaluate` | Eval (`{"useLlm": false}` = chỉ kiểm tra tất định) |
| PATCH | `/quizzes/{quizId}/questions/{qid}` | Giáo viên sửa câu |
| POST | `/quizzes/{quizId}/questions/{qid}/fixes/{fixId}/apply` · `/undo` | Áp dụng / hoàn tác sửa |
| POST | `/slides/scripts` | AI viết lời giảng cho slide trống (PPTist JSON) |
| POST | `/slides/voice` | TTS từng slide, gắn audio element, trả manifest thời lượng |
| POST | `/presentations/{id}/voice` | Voice một presentation đã lưu trong DB (cần đăng nhập) |
| POST | `/voice/synthesize` · GET `/voice/voices` | TTS đơn lẻ / danh sách giọng |

## Trình xem & sửa slide: PPTist

RAGslides đã sinh đúng JSON của PPTist, nên dùng PPTist làm editor:

1. `git clone https://github.com/pipipi-pikachu/PPTist && cd PPTist && npm install`
2. Copy `frontend-integration/pptist/eduguardBridge.ts` vào `PPTist/src/` và gọi
   `installEduguardBridge('http://localhost:3000')` trong `src/main.ts` sau `app.mount('#app')`
   (origin = địa chỉ app React của bạn).
3. `npm run dev` (mặc định http://localhost:5173)
4. Trong React: dùng `frontend-integration/react/PptistEditor.tsx` và `eduApi.ts`.

PPTist dùng giấy phép **AGPL-3.0**: nếu cung cấp sản phẩm cho người khác qua mạng thì phải
công khai mã nguồn phần sửa đổi, hoặc liên hệ tác giả mua giấy phép thương mại.

## Đã kiểm thử

Đề mẫu tiếng Việt có ảnh, bảng gộp ô, công thức OMML, đáp án dạng auto-numbering, câu
Đúng/Sai và trả lời ngắn: trích 5/5 câu, đáp án đúng 5/5 bằng bảng đáp án; bỏ bảng đáp án
vẫn nhận ra đáp án bằng gạch chân và chữ đỏ. Luồng voice: tạo audio, gắn element, cache khi chạy lại.
Chưa kiểm thử: gọi Gemini thật, BE_Zentus thật, API TTS thật, PDF qua Docling.
