from __future__ import annotations

from typing import List, Optional

from app.edu import storage
from app.edu.docparse import load as load_doc
from app.edu.docparse.models import ParsedDocument
from .engines import get_engine
from .evaluator import evaluate_question
from .extractor import extract_questions
from .schemas import EvaluateRequest, GenerateQuizRequest, QuizQuestion, QuizSet, UpdateQuestionRequest


class NotFound(LookupError):
    pass


def _doc(doc_id: str) -> ParsedDocument:
    doc = load_doc(doc_id)
    if not doc:
        raise NotFound(f"document {doc_id} not found")
    return doc


def _media_subset(doc: ParsedDocument, questions: List[QuizQuestion]):
    img_ids, tbl_ids = set(), set()
    for q in questions:
        img_ids.update(q.stem_image_ids)
        img_ids.update(q.source.image_ids)
        tbl_ids.update(q.stem_table_ids)
        for o in q.options:
            img_ids.update(o.image_ids)
    for t in tbl_ids:
        tb = doc.tables.get(t)
        if tb:
            for c in tb.cells:
                for b in c.blocks:
                    img_ids.update(b.image_ids)
    return ({i: doc.images[i] for i in img_ids if i in doc.images},
            {t: doc.tables[t] for t in tbl_ids if t in doc.tables})


def save(qs: QuizSet) -> QuizSet:
    storage.save_json(qs.model_dump(), "quizzes", f"{qs.id}.json")
    return qs


def get(quiz_id: str) -> QuizSet:
    data = storage.load_json("quizzes", f"{storage.check_id(quiz_id)}.json")
    if not data:
        raise NotFound(f"quiz {quiz_id} not found")
    return QuizSet(**data)


def _finish(doc: ParsedDocument, questions: List[QuizQuestion], engine: str, title: str,
            warnings: Optional[List[str]] = None) -> QuizSet:
    images, tables = _media_subset(doc, questions)
    qs = QuizSet(id=storage.new_id("quiz"), doc_id=doc.doc_id, title=title, engine=engine,
                 questions=questions, images=images, tables=tables,
                 original={q.id: q for q in questions}, warnings=warnings or [])
    return save(qs)


def extract(doc_id: str) -> QuizSet:
    doc = _doc(doc_id)
    questions, warnings = extract_questions(doc)
    if not questions:
        warnings.append("Không tìm thấy câu hỏi dạng 'Câu N.' trong tài liệu.")
    return _finish(doc, questions, "extractor", doc.filename, warnings)


async def generate(doc_id: str, req: GenerateQuizRequest) -> QuizSet:
    doc = _doc(doc_id)
    engine = get_engine(req.engine)
    questions = await engine.generate(doc, req)
    return _finish(doc, questions, engine.name, req.title or f"Quiz · {doc.filename}")


async def evaluate(quiz_id: str, req: EvaluateRequest) -> QuizSet:
    qs = get(quiz_id)
    doc = load_doc(qs.doc_id)
    engine = None
    if req.use_llm:
        try:
            engine = get_engine()
        except Exception:
            engine = None  # no API key configured -> deterministic checks only
    targets = set(req.question_ids or [q.id for q in qs.questions])
    import asyncio
    sem = asyncio.Semaphore(4)

    async def one(q: QuizQuestion) -> QuizQuestion:
        if q.id not in targets:
            return q
        async with sem:
            return await evaluate_question(q, doc, engine, req.use_llm)

    qs.questions = list(await asyncio.gather(*(one(q) for q in qs.questions)))
    if doc:
        images, tables = _media_subset(doc, qs.questions)
        qs.images.update(images)
        qs.tables.update(tables)
    return save(qs)


def update_question(quiz_id: str, question_id: str, req: UpdateQuestionRequest) -> QuizQuestion:
    qs = get(quiz_id)
    for i, q in enumerate(qs.questions):
        if q.id == question_id:
            patch = req.model_dump(exclude_none=True)
            q = q.model_copy(update=patch)
            if q.correct_key:
                for o in q.options:
                    if q.type == "mcq":
                        o.is_correct = o.key == q.correct_key
            qs.questions[i] = q
            save(qs)
            return q
    raise NotFound(question_id)


def _set_field(q: QuizQuestion, field: str, value: str) -> QuizQuestion:
    if field == "stem":
        q.stem = value
    elif field == "explanation":
        q.explanation = value
    elif field == "correctKey":
        key = value.strip()[:1].upper()
        q.correct_key = key
        for o in q.options:
            o.is_correct = o.key == key
    elif field.startswith("option"):
        key = field.replace("option", "")
        for o in q.options:
            if o.key == key:
                o.text = value
    return q


def apply_fix(quiz_id: str, question_id: str, fix_id: str, undo: bool = False) -> QuizQuestion:
    qs = get(quiz_id)
    for i, q in enumerate(qs.questions):
        if q.id != question_id:
            continue
        fix = next((f for f in q.fixes if f.id == fix_id), None)
        if not fix:
            raise NotFound(fix_id)
        if undo:
            orig = qs.original.get(q.id)
            if orig:
                field = fix.target_field
                if field == "correctKey":
                    value = orig.correct_key or ""
                elif field.startswith("option"):
                    value = next((o.text for o in orig.options if o.key == field.replace("option", "")), "")
                else:
                    value = getattr(orig, field, "")
                q = _set_field(q, field, value)
            fix.fixed = False
        else:
            if fix.suggested_replacement:
                q = _set_field(q, fix.target_field, fix.suggested_replacement)
            fix.fixed = True
        qs.questions[i] = q
        save(qs)
        return q
    raise NotFound(question_id)
