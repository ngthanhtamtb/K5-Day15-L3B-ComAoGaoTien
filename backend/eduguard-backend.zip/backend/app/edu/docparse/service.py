"""Entry point for document ingestion: upload bytes -> ParsedDocument (+ chunks, markdown)."""
from __future__ import annotations

import logging
import os
from typing import List, Optional

from app.core.config import settings
from app.edu import storage
from .docx_parser import DocxParser
from .models import Block, Chunk, ParsedDocument
from .other_parsers import convert_legacy_office, docling_available, parse_with_docling, parse_with_remote

logger = logging.getLogger(__name__)

SUPPORTED = {".docx", ".doc", ".pdf", ".pptx", ".ppt", ".md", ".txt"}


class UnsupportedDocument(ValueError):
    pass


async def ingest(file_bytes: bytes, filename: str, doc_id: Optional[str] = None) -> ParsedDocument:
    ext = os.path.splitext(filename)[1].lower()
    if ext not in SUPPORTED:
        raise UnsupportedDocument(f"Unsupported file type {ext}. Allowed: {', '.join(sorted(SUPPORTED))}")
    doc_id = doc_id or storage.new_id("doc")
    data_dir = os.path.dirname(storage.path("docs", doc_id, "x"))
    url_prefix = storage.url_for("docs", doc_id)

    if ext in (".doc", ".ppt"):
        target = "docx" if ext == ".doc" else "pptx"
        converted = convert_legacy_office(file_bytes, ext[1:], target)
        if converted is None:
            raise UnsupportedDocument(f"{ext} needs LibreOffice installed for conversion; please save as .{target}")
        file_bytes, ext, filename = converted, f".{target}", os.path.splitext(filename)[0] + f".{target}"

    if ext == ".docx":
        parsed = DocxParser(data_dir, url_prefix).parse(file_bytes, filename, doc_id)
    elif ext in (".md", ".txt"):
        from .other_parsers import _Builder, markdown_to_blocks
        bld = _Builder(data_dir, url_prefix)
        markdown_to_blocks(file_bytes.decode("utf-8", errors="replace"), bld)
        parsed = ParsedDocument(doc_id=doc_id, filename=filename, engine="markdown",
                                blocks=bld.blocks, images=bld.images, tables=bld.tables)
    else:  # pdf / pptx
        engine = settings.EDU_PDF_ENGINE
        if engine == "docling" or (engine == "auto" and docling_available()):
            parsed = parse_with_docling(file_bytes, filename, doc_id, data_dir, url_prefix)
        else:
            parsed = await parse_with_remote(file_bytes, filename, doc_id, data_dir, url_prefix)

    parsed.markdown = to_markdown(parsed)
    parsed.chunks = build_chunks(parsed)
    with open(os.path.join(data_dir, "source" + ext), "wb") as fh:
        fh.write(file_bytes)
    storage.save_json(parsed.model_dump(), "docs", doc_id, "parsed.json")
    return parsed


def load(doc_id: str) -> Optional[ParsedDocument]:
    data = storage.load_json("docs", storage.check_id(doc_id), "parsed.json")
    return ParsedDocument(**data) if data else None


# --------------------------------------------------------------------------- markdown
def _block_md(b: Block, doc: ParsedDocument) -> str:
    if b.type == "table" and b.table:
        return b.table.markdown
    imgs = " ".join(f"![{doc.images[i].alt or i}]({doc.images[i].url})" for i in b.image_ids if i in doc.images)
    text = b.full_text
    if b.type == "heading":
        return f"{'#' * min(b.level or 1, 6)} {text}"
    if b.type == "list_item":
        indent = "  " * (b.level or 0)
        label = b.list_label or "-"
        label = "-" if label == "•" else label
        return f"{indent}{label} {b.text} {imgs}".rstrip()
    return f"{text} {imgs}".strip()


def to_markdown(doc: ParsedDocument) -> str:
    return "\n\n".join(filter(None, (_block_md(b, doc) for b in doc.blocks)))


# --------------------------------------------------------------------------- chunking
def build_chunks(doc: ParsedDocument, target_chars: int = 900) -> List[Chunk]:
    """Heading-aware chunks. A table or image never gets split from the text around it,
    so a quiz question generated from a chunk can still cite its figure/table."""
    chunks: List[Chunk] = []
    heading_path: List[str] = []
    cur_text: List[str] = []
    cur_blocks: List[str] = []
    cur_imgs: List[str] = []
    cur_tbls: List[str] = []
    prefix = doc.doc_id.split("_")[-1][:4].upper()

    def flush():
        text = "\n".join(t for t in cur_text if t).strip()
        if text or cur_imgs:
            chunks.append(Chunk(id=f"{prefix}-C{len(chunks) + 1:03d}", heading_path=list(heading_path),
                                text=text, block_ids=list(cur_blocks), image_ids=list(cur_imgs), table_ids=list(cur_tbls)))
        cur_text.clear(); cur_blocks.clear(); cur_imgs.clear(); cur_tbls.clear()

    for b in doc.blocks:
        if b.type == "heading":
            flush()
            lvl = b.level or 1
            heading_path[:] = heading_path[: lvl - 1] + [b.text]
            continue
        md = _block_md(b, doc)
        if sum(len(t) for t in cur_text) + len(md) > target_chars and cur_text and b.type not in ("table", "image"):
            flush()
        cur_text.append(md)
        cur_blocks.append(b.id)
        cur_imgs.extend(b.image_ids)
        if b.table:
            cur_tbls.append(b.table.id)
            for c in b.table.cells:
                for cb in c.blocks:
                    cur_imgs.extend(cb.image_ids)
    flush()
    return chunks
