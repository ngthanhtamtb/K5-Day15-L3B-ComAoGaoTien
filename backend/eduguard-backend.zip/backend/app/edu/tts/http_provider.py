"""Generic REST TTS provider — configure your API in .env, no code needed for common shapes.

  TTS_PROVIDER=http
  TTS_API_URL=https://your-tts/api/synthesize
  TTS_API_KEY=...                    (sent as  TTS_API_KEY_HEADER: TTS_API_KEY_PREFIX + key)
  TTS_REQUEST_TEMPLATE={"text": "{text}", "voice": "{voice}", "speed": {speed}}
  TTS_RESPONSE_TYPE=binary | json_base64 | json_url
  TTS_RESPONSE_FIELD=data.audio      (dotted path when the response is JSON)
  TTS_AUDIO_EXT=mp3

If your API is asynchronous (submit job -> poll), subclass HttpTTS and override synthesize().
"""
from __future__ import annotations

import base64
import json
import logging

import httpx

from app.core.config import settings
from .base import TTSProvider, TTSResult

logger = logging.getLogger(__name__)
MIME = {"mp3": "audio/mpeg", "wav": "audio/wav", "ogg": "audio/ogg", "m4a": "audio/mp4"}


def _dig(obj, dotted: str):
    for part in dotted.split("."):
        if isinstance(obj, list):
            obj = obj[int(part)]
        else:
            obj = obj[part]
    return obj


class HttpTTS(TTSProvider):
    name = "http"

    def __init__(self):
        if not settings.TTS_API_URL:
            raise RuntimeError("TTS_API_URL is not set")

    def _body(self, text: str, voice: str, speed: float) -> dict:
        # json.dumps escapes quotes/newlines in the script before it goes into the template
        esc = json.dumps(text, ensure_ascii=False)[1:-1]
        raw = (settings.TTS_REQUEST_TEMPLATE.replace("{text}", esc)
               .replace("{voice}", voice).replace("{speed}", str(speed)))
        return json.loads(raw)

    async def synthesize(self, text: str, voice: str, speed: float = 1.0) -> TTSResult:
        headers = {"Content-Type": "application/json"}
        if settings.TTS_API_KEY:
            headers[settings.TTS_API_KEY_HEADER] = f"{settings.TTS_API_KEY_PREFIX}{settings.TTS_API_KEY}"
        ext = settings.TTS_AUDIO_EXT
        async with httpx.AsyncClient(timeout=settings.TTS_TIMEOUT) as client:
            resp = await client.post(settings.TTS_API_URL, json=self._body(text, voice, speed), headers=headers)
            resp.raise_for_status()
            mode = settings.TTS_RESPONSE_TYPE
            if mode == "binary":
                audio = resp.content
            else:
                value = _dig(resp.json(), settings.TTS_RESPONSE_FIELD)
                if mode == "json_base64":
                    audio = base64.b64decode(value.split(",", 1)[-1])
                else:  # json_url
                    audio = (await client.get(value)).content
        return TTSResult(audio, ext, MIME.get(ext, "application/octet-stream"))
