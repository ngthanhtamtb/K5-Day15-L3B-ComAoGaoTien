from __future__ import annotations

from app.core.config import settings
from .base import TTSProvider, TTSResult, concat_audio, split_sentences, wav_duration  # noqa: F401

_provider: TTSProvider | None = None


def get_provider() -> TTSProvider:
    global _provider
    if _provider is None:
        name = settings.TTS_PROVIDER.lower()
        if name == "http":
            from .http_provider import HttpTTS
            _provider = HttpTTS()
        else:
            from .silent_provider import SilentTTS
            _provider = SilentTTS()
    return _provider
