from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.core.auth import get_current_user
from app.models.user import User
from app.models.presentation import Presentation
from app.models.template import Template

router = APIRouter()

async def get_admin_user(current_user: User = Depends(get_current_user)):
    if current_user.email != "admin@smartppt.com":
        raise HTTPException(status_code=403, detail="Admin access required")
    return current_user

@router.get("/users")
async def get_all_users(
    admin_user: User = Depends(get_admin_user),
    db: Session = Depends(get_db)
):
    users = db.query(User).all()
    return users

@router.get("/presentations")
async def get_all_presentations(
    admin_user: User = Depends(get_admin_user),
    db: Session = Depends(get_db)
):
    presentations = db.query(Presentation).all()
    return presentations

@router.get("/system-health")
async def get_system_health(admin_user: User = Depends(get_admin_user)):
    return {
        "status": "healthy",
        "database": "connected",
        "ai_service": "operational",
        "storage": "available"
    }
