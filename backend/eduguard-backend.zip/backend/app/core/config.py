from pydantic_settings import BaseSettings
from typing import Optional, List


class Settings(BaseSettings):
    ENVIRONMENT: str = "development"
    DEBUG: bool = False
    DATABASE_URL: str = "postgresql://user:password@localhost/smartppt"

    SECRET_KEY: str = "change-this-secret-key-in-production-use-env-file"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 3
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7

    GEMINI_API_KEY: str = ""  # Set this in .env file
    PROMPT_TEMPERATURE: float = 0.3
    PROMPT_TOP_K: int = 1
    PROMPT_TOP_P: float = 0.9
    PROMPT_MAX_OUTPUT_TOKENS: int = 25000
    GEMINI_API_URL: str = "https://generativelanguage.googleapis.com/v1beta/models"
    EXTRACT_DOC_API_URL: str = "http://124.158.5.35:9033/documents/convert"

    MAX_FILE_SIZE: Optional[int] = 10 * 1024 * 1024  # 10MB
    TEMPLATE_DIR: Optional[str] = "data/templates"
    UPLOAD_TEMPLATES_DIR: Optional[str] = "data/uploads/templates"
    UPLOAD_PAGE_DIR: Optional[str] = "data/uploads/pages"
    UPLOAD_DIRS: List[str] = [
        "data/uploads/media", "data/uploads/templates", "data/uploads/pages",
        "data/uploads/presentations", "data/uploads/avatars",
    ]

    IMAGES_DIR: str = "data/images/templates"
    SUPPORTED_EXTENSIONS: set = {'.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp', '.svg'}
    ALLOWED_FILE_TYPES: dict = {
        ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        ".md": "text/markdown",
        ".csv": "text/csv",
        ".txt": "text/plain",
    }

    FERNET_KEY: str = ""

    # ===== EduGuard extensions (app/edu) =====
    EDU_DATA_DIR: str = "data/edu"              # served under /static/edu/...
    EDU_PUBLIC_BASE_URL: str = ""               # e.g. http://localhost:8077 ; empty = relative URLs
    EDU_MAX_UPLOAD_MB: int = 50

    # Document parsing: docx -> native parser; pdf/pptx -> "docling" (local) | "remote" (EXTRACT_DOC_API_URL)
    EDU_PDF_ENGINE: str = "auto"

    # Quiz engine: "zentus" (BE_Zentus core) | "gemini" (RAGslides LLM client). Falls back to gemini.
    QUIZ_ENGINE: str = "zentus"
    QUIZ_MODEL: str = "gemini-2.5-flash"
    ZENTUS_PATH: str = ""                       # e.g. E:/Python_Project/VinAI_Lab/BE_Zentus
    ZENTUS_GENERATE_FN: str = ""                # "package.module:function" for quiz generation
    ZENTUS_EVALUATE_FN: str = ""                # optional "package.module:function" for quiz eval

    # Text-to-speech: "silent" (dev, no API) | "http" (generic REST API, configured below)
    TTS_PROVIDER: str = "silent"
    TTS_API_URL: str = ""
    TTS_API_KEY: str = ""
    TTS_API_KEY_HEADER: str = "Authorization"   # header name
    TTS_API_KEY_PREFIX: str = "Bearer "         # header value prefix
    TTS_REQUEST_TEMPLATE: str = '{"text": "{text}", "voice": "{voice}", "speed": {speed}}'
    TTS_RESPONSE_TYPE: str = "binary"           # binary | json_base64 | json_url
    TTS_RESPONSE_FIELD: str = "audio"           # dotted path for json_* modes, e.g. data.audio_url
    TTS_AUDIO_EXT: str = "mp3"
    TTS_DEFAULT_VOICE: str = "default"
    TTS_MAX_CHARS: int = 1500                   # long scripts are split by sentence
    TTS_TIMEOUT: float = 120.0

    SMTP_HOST: Optional[str] = None
    SMTP_PORT: Optional[int] = None
    SMTP_USER: Optional[str] = None
    SMTP_PASSWORD: Optional[str] = None

    class Config:
        env_file = ".env"


settings = Settings()
